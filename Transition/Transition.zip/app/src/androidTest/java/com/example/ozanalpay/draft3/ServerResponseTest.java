package com.example.ozanalpay.draft3;

/**
 * Created by OzanAlpay on 24.5.2015.
 */
public class ServerResponseTest {
}
