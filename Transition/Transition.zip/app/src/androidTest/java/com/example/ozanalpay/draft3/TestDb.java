package com.example.ozanalpay.draft3;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.test.AndroidTestCase;

import com.example.ozanalpay.draft3.data.data.FindATourDbContract;
import com.example.ozanalpay.draft3.data.data.FindATourDbHelper;

/**
 * Created by OzanAlpay on 24.5.2015.
 */
public class TestDb extends AndroidTestCase {

    public static final String LOG = TestDb.class.getSimpleName();

    public long addExampleData(){
        SQLiteDatabase tourDB = new FindATourDbHelper(this.mContext).getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(FindATourDbContract.TouristEntry.COLUMN_TOURIST_NAME, "John");
        contentValues.put(FindATourDbContract.TouristEntry.COLUMN_TOURIST_SURNAME, "Doe");
        contentValues.put(FindATourDbContract.TouristEntry.COLUMN_TOURIST_EMAIL, "john@doe.com");
        long id = tourDB.insert(FindATourDbContract.TouristEntry.TABLE_NAME, null, contentValues);

        assertTrue("Error: Failure to insert John Doe  Values", id != -1);
        return id;

    }
    public void deleteExampleData(){
        String email = "john@doe.com";
        SQLiteDatabase tourDB = new FindATourDbHelper(this.mContext).getWritableDatabase();
        String deleteQuery = "DELETE FROM " + FindATourDbContract.TouristEntry.TABLE_NAME + " WHERE " +
                FindATourDbContract.TouristEntry.COLUMN_TOURIST_EMAIL + " = " + email + ";";
        tourDB.rawQuery(deleteQuery,null);

    }

    public void setUp(){

        deleteExampleData();
        addExampleData();

    }
}
