package com.example.ozanalpay.draft3.data.data;

import android.provider.BaseColumns;

/**
 * Created by OzanAlpay on 20.5.2015.
 */
public class FindATourDbContract {


    public static final class TouristEntry implements BaseColumns {

        public static final String TABLE_NAME = "tourist";
        public static final String COLUMN_TOURIST_NAME = "name";
        public static final String COLUMN_TOURIST_SURNAME = "surname";
        public static final String COLUMN_TOURIST_EMAIL = "email";



    }
    public static final class PlaceEntry implements BaseColumns {

        public static final String TABLE_NAME = "place";
        public static final String COLUMN_PLACE_NAME = "name";
        public static final String COLUMN_PLACE_DESCRIPTION = "description";
    }
    public static final class BadgeEntry implements BaseColumns {

        public static final String TABLE_NAME = "badge";
        public static final String COLUMN_BADGE_NAME = "name";
        public static final String COLUMN_BADGE_DESCRIPTION = "description";

    }
    public static final class TourGuideEntry implements BaseColumns {

        public static final String TABLE_NAME = "tourguide";
        public static final String COLUMN_TOUR_GUIDE_NAME = "name";
        public static final String COLUMN_TOUR_GUIDE_SURNAME = "surname";
        public static final String COLUMN_TOUR_GUIDE_EMAIL = "email";

        public static final String COLUMN_TOUR_GUIDE_RATING = "rating";

    }
    public static final class TourAdminEntry implements BaseColumns {

        public static final String TABLE_NAME = "touradmin";
        public static final String COLUMN_TOUR_ADMIN_EMAIL = "email";


    }
    public static final class TourEntry implements BaseColumns {

        public static final String TABLE_NAME = "tour";
        public static final String COLUMN_TOUR_NAME = "name";
        public static final String COLUMN_TOUR_CITY = "cityname";
        public static final String COLUMNN_TOUR_LANGUAGE = "tourlanguage";
        public static final String COLUMN_TOUR_START_DATE = "startdate";
        public static final String COLUMN_TOUR_END_DATE = "enddate";
        public static final String COLUMN_PROMOTED = "isporomoted";
        public static final String COLUMN_TOUR_PRICE = "tourprice";
        public static final String COLUMN_NUMBER_OF_PARTICIPANTS = "numberofparticipants";
        public static final String COLUMN_LIMIT_OF_PARTICIPANTS = "limitofparticipants";
        public static final String COLUMN_TOUR_TOUR_GUIDE_KEY = "tourguideid";

    }
    public static final class TouristTourEntry implements BaseColumns {

        public static final String TABLE_NAME = "touristtour";
        public static final String COLUMN_TOURIST_KEY = "touristid";
        public static final String COLUMNT_TOUR_ID = "tourid";
        public static final String COLUMN_TOUR_TOURIST_GRADE = "tourgrade";

    }
    public static final class TourGuideBadgeEntry implements BaseColumns{

        public static final String TABLE_NAME = "tourguidebadge";
        public static final String COLUMN_TOUR_GUIDE_KEY = "tourguidekey";
        public static final String COLUMN_BADGE_KEY = "badgekey";

    }
    public static final class TourPlaceEntry implements BaseColumns {

        public static final String TABLE_NAME = "tourplace";
        public static final String COLUMN_TOUR_KEY = "tourid";
        public static final String COLUMN_PLACE_KEY = "placeid";
    }









}
