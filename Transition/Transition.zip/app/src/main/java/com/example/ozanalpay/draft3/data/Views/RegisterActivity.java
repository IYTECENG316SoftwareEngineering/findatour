package com.example.ozanalpay.draft3.data.Views;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.ozanalpay.draft3.R;
import com.example.ozanalpay.draft3.data.application.AppConfig;
import com.example.ozanalpay.draft3.data.application.AppController;
import com.example.ozanalpay.draft3.data.data.FindATourDbHelper;
import com.example.ozanalpay.draft3.data.helper.SessionManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends Activity {

    private static final String TAG = RegisterActivity.class.getSimpleName();
    private Button registerButton;
    private Button goToLoginScreenButton;
    private EditText inputName;
    private EditText inputSurname;
    private EditText inputEmailAddress;
    private EditText inputPassword;
    private ProgressDialog pDialog;
    private SessionManager sessionManager;
    private FindATourDbHelper tourDbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        inputName = (EditText) findViewById(R.id.register_name_input);
        inputSurname = (EditText) findViewById(R.id.register_surname_input);
        inputEmailAddress = (EditText) findViewById(R.id.register_email_input);
        inputPassword = (EditText) findViewById(R.id.register_password_input);
        registerButton = (Button) findViewById(R.id.register_button);
        goToLoginScreenButton = (Button) findViewById(R.id.go_to_login_button);

        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);

        sessionManager = new SessionManager(getApplicationContext());

        tourDbHelper = new FindATourDbHelper(getApplicationContext());

        if(sessionManager.isLoggedIn())
        {
            Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        }
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = inputName.getText().toString();
                String surname = inputSurname.getText().toString();
                String email = inputEmailAddress.getText().toString();
                String password = inputPassword.getText().toString();

                if(!("".equals(name)) && !("".equals(surname)) && !("".equals(email)) && !("".equals(password)))
                {

                    registerUser(name, surname, email, password);
                }
                else
                {
                    Log.d(TAG,"Input name is = "+name+" Input surname is = "+surname+" Input mail is = "+email+ " Input password is = "+password);
                    Toast.makeText(getApplicationContext()," Please fulfill all the areas!",Toast.LENGTH_LONG).show();
                }

            }
        });
        goToLoginScreenButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });




    }
    public void registerUser(final String name, final String surname, final String email, final String password) {
        String tag_register_tourist = "register_tourist";

        pDialog.setMessage("Please Wait...");
        pDialog.show();

        StringRequest strReq = new StringRequest(Request.Method.POST, AppConfig.URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d(TAG, "Register Response from PHP Server : " + response.toString());
                pDialog.dismiss();


                try {
                    JSONObject jsonObject = new JSONObject(response);
                    boolean error = jsonObject.getBoolean("error");
                    if (!error) {
                        //String touristID = jsonObject.getString("uid");
                        JSONObject tourist = jsonObject.getJSONObject("tourist");
                        String name = tourist.getString("name");
                        String surname = tourist.getString("surname");
                        String email = tourist.getString("email");

                        tourDbHelper.addTourist(name, surname, email);
                        Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        String errorMessage = jsonObject.getString("error_msg");
                        Toast.makeText(getApplicationContext(), errorMessage, Toast.LENGTH_LONG).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                Log.e(TAG, "Error During Registiration Process Details : " + volleyError.getMessage());
                Toast.makeText(getApplicationContext(), volleyError.getMessage(), Toast.LENGTH_LONG).show();
                pDialog.hide();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("tag", "register_tourist");
                params.put("name", name);
                params.put("surname", surname);
                params.put("email", email);
                params.put("password", password);
                return params;
            }
        };
        AppController.getInstance().addToRequestQueue(strReq, tag_register_tourist);
    }

















    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_register_activiyu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
