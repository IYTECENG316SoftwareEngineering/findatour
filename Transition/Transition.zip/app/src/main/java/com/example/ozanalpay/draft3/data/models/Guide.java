package com.example.ozanalpay.draft3.data.models;

/**
 * Created by OzanAlpay on 22.5.2015.
 */
public class Guide extends User {

    private String surname;
    private int grade;

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public Guide(int userId, String name, String emailAdress, String surname, int grade) {
        super(userId, name, emailAdress);
        this.surname = surname;
        this.grade = grade;
        this.setUserType(Usertype.GUIDE);
    }
}
