package com.example.ozanalpay.draft3.data.Views;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.ozanalpay.draft3.R;
import com.example.ozanalpay.draft3.data.application.AppConfig;
import com.example.ozanalpay.draft3.data.application.AppController;
import com.example.ozanalpay.draft3.data.data.FindATourDbHelper;
import com.example.ozanalpay.draft3.data.helper.SessionManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class GuideHomeActivity extends ActionBarActivity {
    private final String TAG = GuideHomeActivity.class.getSimpleName();
    private EditText tourNameInput;
    private EditText tourCityNameInput;
    private EditText tourPlacesInput;
    private EditText tourLanguageInput;
    private EditText tourTicketPriceInput;
    private EditText tourMaxSizeInput;
    private Button selectTourDateButton;
    private Button selectTourStartHourButton;
    private Button selectTourEndHourButton;
    private Button lookUpcomingToursButton;
    private Button logoutButton;
    private Button createTourButton;
    private SessionManager sessionManager;
    private FindATourDbHelper tourDbHelper;
    private ProgressDialog pDialog;
    public int inputDay,inputMonth,inputYear;
    public int startHour,startMinute;
    public int endHour,endMinute;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide_home);
        tourNameInput = (EditText)findViewById(R.id.guide_home_tour_name_input);
        tourCityNameInput = (EditText) findViewById(R.id.guide_home_tour_city_input);

        tourLanguageInput = (EditText) findViewById(R.id.guide_home_tour_language_input);
        tourTicketPriceInput = (EditText)findViewById(R.id.guide_home_input_max_tour_size);
        tourMaxSizeInput = (EditText) findViewById(R.id.guide_home_tour_price_input);
        selectTourDateButton = (Button)findViewById(R.id.guide_home_tour_start_date_input);
        selectTourStartHourButton = (Button) findViewById(R.id.guide_home_tour_start_hour_input_button);
        selectTourEndHourButton = (Button) findViewById(R.id.guide_home_tour_end_hour_input_button);
        lookUpcomingToursButton = (Button) findViewById(R.id.guide_home_look_upcoming_tours_button);
        logoutButton = (Button) findViewById(R.id.guide_home_logout_button);
        createTourButton  = (Button) findViewById(R.id.guide_home_create_tour_button);
        tourDbHelper = new FindATourDbHelper(getApplicationContext());
        sessionManager = new SessionManager(getApplicationContext());
        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);

        selectTourDateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Calendar CurrentDay = Calendar.getInstance();
                int day = CurrentDay.get(Calendar.DAY_OF_MONTH);
                int month = CurrentDay.get(Calendar.MONTH);
                int year = CurrentDay.get(Calendar.YEAR);

                DatePickerDialog datePickerDialog;

                datePickerDialog =  new DatePickerDialog(GuideHomeActivity.this, new DatePickerDialog.OnDateSetListener(){
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int day)
                    {
                        Log.d(TAG, "User selected Date as Day = " + day + " Month = " + month + " Year = " + year);
                        inputYear = year;
                        inputMonth = month;
                        inputDay = day;
                    }
                },year, month, day);
                datePickerDialog.setTitle("Pick Tour Date");
                datePickerDialog.setButton(DatePickerDialog.BUTTON_POSITIVE, "Set", datePickerDialog);
                datePickerDialog.setButton(DatePickerDialog.BUTTON_NEGATIVE, "Cancel", datePickerDialog);
                datePickerDialog.show();
             }});
        selectTourEndHourButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar currentTime = Calendar.getInstance();
                int hour = currentTime.get(Calendar.HOUR_OF_DAY);
                int minute = currentTime.get(Calendar.MINUTE);
                TimePickerDialog timePickerDialog;

                timePickerDialog = new TimePickerDialog(GuideHomeActivity.this, new TimePickerDialog.OnTimeSetListener(){

                    @Override
                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute)
                    {
                        Log.d(TAG,"User selected the end time as Hour="+ selectedHour +" Minute=" +selectedMinute);
                        endHour = selectedHour;
                        endMinute = selectedMinute;

                    }

                },hour,minute,true);

                timePickerDialog.setTitle("Pick A End Hour");
                timePickerDialog.setButton(DatePickerDialog.BUTTON_POSITIVE, "Set", timePickerDialog);
                timePickerDialog.setButton(DatePickerDialog.BUTTON_NEGATIVE, "Cancel", timePickerDialog);
                timePickerDialog.show();
            }
        });
        selectTourStartHourButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Calendar currentTime = Calendar.getInstance();
                int hour = currentTime.get(Calendar.HOUR_OF_DAY);
                int minute = currentTime.get(Calendar.MINUTE);
                TimePickerDialog timePickerDialog;

                timePickerDialog = new TimePickerDialog(GuideHomeActivity.this, new TimePickerDialog.OnTimeSetListener(){

                    @Override
                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute)
                    {
                        Log.d(TAG,"User selected the start time as Hour="+selectedHour+" Minute="+selectedMinute);
                        startHour = selectedHour;
                        startMinute = selectedMinute;

                    }

                },hour,minute,true);

                timePickerDialog.setTitle("Pick Start Hour");
                timePickerDialog.setButton(DatePickerDialog.BUTTON_POSITIVE, "Set", timePickerDialog);
                timePickerDialog.setButton(DatePickerDialog.BUTTON_NEGATIVE, "Cancel", timePickerDialog);
                timePickerDialog.show();
            }
        });
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logoutUser();
            }
        });
        createTourButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inputTourName = tourNameInput.getText().toString();
                String inputCityName = tourCityNameInput.getText().toString();
                String inputTicketPrice = tourTicketPriceInput.getText().toString();
                String inputTourLanguage = tourLanguageInput.getText().toString();
                String inputTourMaxSize = tourMaxSizeInput.getText().toString();

                String inputStartDate = String.valueOf(inputYear)+"-"+String.valueOf(inputMonth)+"-"+String.valueOf(inputDay)+" "+
                        String.valueOf(startHour)+":"+String.valueOf(startMinute)+":00";
                String inputEndDate = String.valueOf(inputYear)+"-"+String.valueOf(inputMonth)+"-"+String.valueOf(inputDay)+" "+
                        String.valueOf(endHour)+":"+String.valueOf(endMinute)+":00";
                Log.d(TAG,inputStartDate);
                Log.d(TAG,inputEndDate);


                if(!("".equals(inputCityName)) && !("".equals(inputTourName)) && !("".equals(inputTourLanguage)))
                {

                    insertTour(inputTourName, inputCityName, inputTicketPrice, inputTourLanguage, inputTourMaxSize, inputStartDate, inputEndDate);
                }
                else
                {

                    Toast.makeText(getApplicationContext()," Please fulfill all the areas!",Toast.LENGTH_LONG).show();
                }























            }
        });

    }
    public void insertTour(final String tourName, final String cityName, final String ticketPrice, final  String language, final String tourMaxSize, final String startDate, final String endDate)
    {
        String tag_insert_tour = "insert_tour";

        pDialog.setMessage("Please Wait...");
        pDialog.show();

        StringRequest strReq = new StringRequest(Request.Method.POST, AppConfig.URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d(TAG, "Register Response from PHP Server : " + response.toString());
                pDialog.dismiss();


                try {
                    JSONObject jsonObject = new JSONObject(response);
                    boolean error = jsonObject.getBoolean("error");
                    if (!error) {
                        Log.d(TAG,"Tour Succesfully Inserted!");


                    } else {
                        String errorMessage = jsonObject.getString("error_msg");
                        Toast.makeText(getApplicationContext(), errorMessage, Toast.LENGTH_LONG).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                Log.e(TAG, "Error During Tour Insertion Process Details : " + volleyError.getMessage());
                Toast.makeText(getApplicationContext(), volleyError.getMessage(), Toast.LENGTH_LONG).show();
                pDialog.hide();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("tag", "insert_tour");
                params.put("name", tourName);
                params.put("city_name", cityName);
                params.put("language", language);
                params.put("price", ticketPrice );
                params.put("tourSize", tourMaxSize);
                params.put("startDate", startDate);
                params.put("endDate", endDate);
                params.put("tour_guide_mail","ozanalpay@std.iyte.edu.tr");
                return params;
            }
        };
        AppController.getInstance().addToRequestQueue(strReq, tag_insert_tour);











    }

    private void logoutUser(){
        sessionManager.setLogin(false);
        tourDbHelper.deleteUsers();
        Intent intent = new Intent(GuideHomeActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_guide_home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
