package com.example.ozanalpay.draft3.data.models;

/**
 * Created by OzanAlpay on 22.5.2015.
 */
public class Tourist extends User {

    private String surname;

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public Tourist(int userId, String name, String emailAdress, String surname) {
        super(userId, name, emailAdress);
        this.surname = surname;
        this.setUserType(Usertype.TOURIST);
    }

}
