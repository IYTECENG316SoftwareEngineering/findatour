package com.example.ozanalpay.draft3.data.helper;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.util.Log;

/**
 * Created by OzanAlpay on 20.5.2015.
 */
public class SessionManager {


    private String TAG = SessionManager.class.getSimpleName();
    SharedPreferences pref;
    Editor editor;
    Context tempContext;
    int PRIVATE_MODE = 0;

    private static final String PREF_NAME = "FindATourLogin";
    private static final String KEY_IS_LOGGED_IN = "isLoggedIn";

    public SessionManager(Context context)
    {
        this.tempContext = context;
        pref = tempContext.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();

    }
    public void setLogin(boolean isLoggedIn)
    {
        editor.putBoolean(KEY_IS_LOGGED_IN, isLoggedIn);

        editor.commit();
        Log.d(TAG, "User Login applied into SharedPreferences");
    }
    public boolean isLoggedIn()
    {
        return pref.getBoolean(KEY_IS_LOGGED_IN, false);

    }




}
