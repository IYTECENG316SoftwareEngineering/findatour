package com.example.ozanalpay.draft3.data.application;

/**
 * Created by OzanAlpay on 20.5.2015.
 */
public class AppConfig {

    public static String URL = "http://themagusmedivh.mywebcommunity.org";




}
