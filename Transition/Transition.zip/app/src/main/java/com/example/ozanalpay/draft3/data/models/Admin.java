package com.example.ozanalpay.draft3.data.models;

/**
 * Created by OzanAlpay on 22.5.2015.
 */
public class Admin extends User {

    public Admin(int userId, String name, String emailAdress) {
        super(userId, name, emailAdress);
        this.setUserType(Usertype.ADMIN);
    }
}
