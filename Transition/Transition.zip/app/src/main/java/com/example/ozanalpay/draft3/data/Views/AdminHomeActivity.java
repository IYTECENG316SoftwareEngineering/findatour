package com.example.ozanalpay.draft3.data.Views;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.ozanalpay.draft3.R;
import com.example.ozanalpay.draft3.data.application.AppConfig;
import com.example.ozanalpay.draft3.data.application.AppController;
import com.example.ozanalpay.draft3.data.data.FindATourDbHelper;
import com.example.ozanalpay.draft3.data.helper.SessionManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AdminHomeActivity extends ActionBarActivity {
    private static final String TAG = "AdminHomeActivity";
    private EditText inputNameForRegister;
    private EditText inputSurnameForRegister;
    private EditText inputEmailForRegister;
    private EditText inputPasswordForRegister;
    private EditText inputEmailForDelete;
    private Button newUserButton;
    private Button deleteUserButton;
    private Button logoutButton;
    private ProgressDialog pDialog;
    private SessionManager sessionManager;
    private FindATourDbHelper tourDbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_home);

        inputNameForRegister = (EditText)findViewById(R.id.admin_home_input_tour_guide_name);
        inputSurnameForRegister = (EditText) findViewById(R.id.admin_home_input_tour_guide_surname);
        inputEmailForRegister = (EditText)findViewById(R.id.admin_home_input_tour_guide_email);
        inputPasswordForRegister = (EditText) findViewById(R.id.admin_home_input_tour_guide_password);
        inputEmailForDelete = (EditText)findViewById(R.id.admin_home_delete_user_input);
        newUserButton = (Button)findViewById(R.id.admin_home_add_tour_guide_button);
        deleteUserButton = (Button) findViewById(R.id.admin_home_delete_user_button);
        logoutButton = (Button) findViewById(R.id.admin_home_logout_button);
        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);
        tourDbHelper = new FindATourDbHelper(getApplicationContext());
        sessionManager = new SessionManager(getApplicationContext());


        newUserButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = inputNameForRegister.getText().toString();
                String surname = inputSurnameForRegister.getText().toString();
                String email = inputEmailForRegister.getText().toString();
                String password = inputPasswordForRegister.getText().toString();

                if(!("".equals(name) || "".equals(surname) || "".equals(email) || "".equals(password)))
                {
                    RegisterTourGuide(name, surname, email, password);
                }
                else
                {

                    Toast.makeText(getApplicationContext()," Please fulfill all the areas!",Toast.LENGTH_LONG).show();
                }

            }
        });
        deleteUserButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = inputEmailForDelete.getText().toString();
                if(!("".equals(email)))
                {
                    Log.d(TAG,"Delete request with user e-mail address = " + email);
                    deleteUser(email);

                }
                else
                {
                    Toast.makeText(getApplicationContext()," Please fulfill all the areas!",Toast.LENGTH_LONG).show();

                }


            }
        });
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                logoutUser();
            }
        });






    }
    private void logoutUser(){
        sessionManager.setLogin(false);
        tourDbHelper.deleteUsers();
        Intent intent = new Intent(AdminHomeActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }




    private void deleteUser(final String email) {
        String tag_string_req = "req_delete_user";
        pDialog.setMessage("Please Wait");
        pDialog.show();

        StringRequest requestString = new StringRequest(Request.Method.POST, AppConfig.URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d(TAG, " Delete User Response : " + response.toString());
                pDialog.dismiss();

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    boolean error = jsonObject.getBoolean("error");
                    if (!error) {
                        tourDbHelper.deleteUser(email);
                        Toast.makeText(getApplicationContext(), " User successfully deleted!", Toast.LENGTH_LONG).show();

                        Intent intent = new Intent(AdminHomeActivity.this, AdminHomeActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        String errorMessage = jsonObject.getString("error_msg");
                        Toast.makeText(getApplicationContext(), errorMessage, Toast.LENGTH_LONG).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError vError) {
                Log.e(TAG, "Error on User Deleting Process!: " + vError.getMessage());
                Toast.makeText(getApplicationContext(), vError.getMessage(), Toast.LENGTH_LONG).show();
                pDialog.hide();
            }
        }) {

            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<String, String>();
                params.put("tag", "delete_user");

                params.put("email", email);



                return params;

            }


        };
        AppController.getInstance().addToRequestQueue(requestString, tag_string_req);
    }

    private void RegisterTourGuide(final String name, final String surname, final String email, final String password)
    {
        String tag_string_req = "req_register_tour_guide";
        pDialog.setMessage("Please Wait");
        pDialog.show();

        StringRequest requestString = new StringRequest(Request.Method.POST, AppConfig.URL, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Log.d(TAG, " Tour Guide Insert Response: " + response.toString());
                pDialog.hide();


                try {
                    JSONObject jsonObject = new JSONObject(response);
                    boolean error = jsonObject.getBoolean("error");
                    if (!error) {

                        String tour_guide_id = jsonObject.getString("tid");
                        JSONObject tour_guide = jsonObject.getJSONObject("tour_guide");
                        String name = tour_guide.getString("name");
                        String surname = tour_guide.getString("surname");
                        String email = tour_guide.getString("email");

                        tourDbHelper.addTourGuide(name, surname, email);
                        Intent intent = new Intent(AdminHomeActivity.this, AdminHomeActivity.class);
                        startActivity(intent);
                        finish();








                    } else {
                        String errorMessage = jsonObject.getString("error_msg");
                        Toast.makeText(getApplicationContext(), errorMessage, Toast.LENGTH_LONG).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError vError) {
                Log.e(TAG, " Tour Guide Creating Error!: " + vError.getMessage());
                Toast.makeText(getApplicationContext(), vError.getMessage(), Toast.LENGTH_LONG).show();
                pDialog.hide();
            }
        }) {


            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<String, String>();
                params.put("tag", "register_tour_guide");
                params.put("name",name);
                params.put("surname",surname);
                params.put("email", email);
                params.put("password", password);

                return params;
            }
        };


        AppController.getInstance().addToRequestQueue(requestString, tag_string_req);
    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_admin_home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
