package com.example.ozanalpay.draft3.data.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.HashMap;

/**
 * Created by OzanAlpay on 20.5.2015.
 */
public class FindATourDbHelper extends SQLiteOpenHelper {

    private static final String TAG = FindATourDbHelper.class.getSimpleName();
    private static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "tour.db";
    public final String SQL_CREATE_TOURIST_TABLE = "CREATE TABLE "+ FindATourDbContract.TouristEntry.TABLE_NAME + " (" +
            FindATourDbContract.TouristEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            FindATourDbContract.TouristEntry.COLUMN_TOURIST_NAME + " TEXT NOT NULL," +
            FindATourDbContract.TouristEntry.COLUMN_TOURIST_SURNAME + " TEXT NOT NULL," +
            FindATourDbContract.TouristEntry.COLUMN_TOURIST_EMAIL + " TEXT NOT NULL UNIQUE);";

    public final String SQL_CREATE_PLACE_TABLE = "CREATE TABLE " + FindATourDbContract.PlaceEntry.TABLE_NAME + " (" +
            FindATourDbContract.PlaceEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            FindATourDbContract.PlaceEntry.COLUMN_PLACE_NAME + " TEXT NOT NULL," +
            FindATourDbContract.PlaceEntry.COLUMN_PLACE_DESCRIPTION + " TEXT NOT NULL);";
    public final String SQL_CREATE_TOUR_GUIDE_TABLE = "CREATE TABLE " + FindATourDbContract.TourGuideEntry.TABLE_NAME + " (" +
            FindATourDbContract.TourGuideEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            FindATourDbContract.TourGuideEntry.COLUMN_TOUR_GUIDE_NAME + " TEXT NOT NULL," +
            FindATourDbContract.TourGuideEntry.COLUMN_TOUR_GUIDE_SURNAME + " TEXT NOT NULL," +
            FindATourDbContract.TourGuideEntry.COLUMN_TOUR_GUIDE_EMAIL + " TEXT NOT NULL UNIQUE, " +

            FindATourDbContract.TourGuideEntry.COLUMN_TOUR_GUIDE_RATING + " REAL);";
    public final String SQL_CREATE_TOUR_ADMIN_TABLE = "CREATE TABLE " + FindATourDbContract.TourAdminEntry.TABLE_NAME + " (" +
            FindATourDbContract.TourAdminEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            FindATourDbContract.TourAdminEntry.COLUMN_TOUR_ADMIN_EMAIL + " TEXT NOT NULL);";

    public static final String SQL_CREATE_BADGE_TABLE = "CREATE TABLE " + FindATourDbContract.BadgeEntry.TABLE_NAME + " (" +
            FindATourDbContract.BadgeEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            FindATourDbContract.BadgeEntry.COLUMN_BADGE_NAME + "TEXT NOT NULL," +
            FindATourDbContract.BadgeEntry.COLUMN_BADGE_DESCRIPTION + "TEXT NOT NULL);";
    public static final String SQL_CREATE_TOUR_TABLE = "CREATE TABLE " + FindATourDbContract.TourEntry.TABLE_NAME + " (" +
            FindATourDbContract.TourEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            FindATourDbContract.TourEntry.COLUMN_TOUR_NAME + " TEXT NOT NULL," +
            FindATourDbContract.TourEntry.COLUMN_TOUR_CITY + " TEXT NOT NULL," +
            FindATourDbContract.TourEntry.COLUMNN_TOUR_LANGUAGE + " TEXT NOT NULL," +
            FindATourDbContract.TourEntry.COLUMN_LIMIT_OF_PARTICIPANTS + " INTEGER," +
            FindATourDbContract.TourEntry.COLUMN_NUMBER_OF_PARTICIPANTS + " INTEGER," +
            FindATourDbContract.TourEntry.COLUMN_TOUR_PRICE + " INTEGER," +
            FindATourDbContract.TourEntry.COLUMN_PROMOTED + " INTEGER," +
            FindATourDbContract.TourEntry.COLUMN_TOUR_START_DATE + " DATETIME NOT NULL," +
            FindATourDbContract.TourEntry.COLUMN_TOUR_END_DATE + " DATETIME NOT NULL," +
            FindATourDbContract.TourEntry.COLUMN_TOUR_TOUR_GUIDE_KEY + " INTEGER," +
            " FOREIGN KEY("+ FindATourDbContract.TourEntry.COLUMN_TOUR_TOUR_GUIDE_KEY+") REFERENCES "+
            FindATourDbContract.TourGuideEntry.TABLE_NAME+"(_id));";
    public static final String SQL_CREATE_TOURIST_TOUR_TABLE = "CREATE TABLE "+ FindATourDbContract.TouristTourEntry.TABLE_NAME + " (" +
            FindATourDbContract.TouristTourEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            FindATourDbContract.TouristTourEntry.COLUMN_TOURIST_KEY + " INTEGER,"+
            FindATourDbContract.TouristTourEntry.COLUMNT_TOUR_ID + " INTEGER,"+
            FindATourDbContract.TouristTourEntry.COLUMN_TOUR_TOURIST_GRADE + " INTEGER,"+
            " FOREIGN KEY("+ FindATourDbContract.TouristTourEntry.COLUMN_TOURIST_KEY+") REFERENCES " +
            FindATourDbContract.TouristEntry.TABLE_NAME+ "("+ FindATourDbContract.TouristEntry._ID+"),"+
            " FOREIGN KEY("+ FindATourDbContract.TouristTourEntry.COLUMNT_TOUR_ID+") REFERENCES " +
            FindATourDbContract.TourEntry.TABLE_NAME + "("+ FindATourDbContract.TourEntry._ID+"));";

    public static final String SQL_CREATE_TOUR_PLACE_TABLE = "CREATE TABLE "+ FindATourDbContract.TourPlaceEntry.TABLE_NAME + " (" +
            FindATourDbContract.TourPlaceEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            FindATourDbContract.TourPlaceEntry.COLUMN_PLACE_KEY + " INTEGER," +
            FindATourDbContract.TourPlaceEntry.COLUMN_TOUR_KEY + " INTEGER," +
            " FOREIGN KEY("+ FindATourDbContract.TourPlaceEntry.COLUMN_TOUR_KEY+") REFERENCES " +
            FindATourDbContract.TourEntry.TABLE_NAME+"("+ FindATourDbContract.TourEntry._ID +")," +
            " FOREIGN KEY("+ FindATourDbContract.TourPlaceEntry.COLUMN_PLACE_KEY+") REFERENCES " +
            FindATourDbContract.PlaceEntry.TABLE_NAME +"("+ FindATourDbContract.PlaceEntry._ID+"));";
    public static final String SQL_CREATE_TOUR_GUIDE_BADGE_TABLE = "CREATE TABLE " + FindATourDbContract.TourGuideBadgeEntry.TABLE_NAME+ " ("+
            FindATourDbContract.TourGuideBadgeEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            FindATourDbContract.TourGuideBadgeEntry.COLUMN_TOUR_GUIDE_KEY + " INTEGER,"+
            FindATourDbContract.TourGuideBadgeEntry.COLUMN_BADGE_KEY + " INTEGER,"+
            " FOREIGN KEY("+ FindATourDbContract.TourGuideBadgeEntry.COLUMN_TOUR_GUIDE_KEY+") REFERENCES "+
            FindATourDbContract.TourGuideEntry.TABLE_NAME+"("+ FindATourDbContract.TourGuideEntry._ID+"),"+
            " FOREIGN KEY("+ FindATourDbContract.TourGuideBadgeEntry.COLUMN_BADGE_KEY+") REFERENCES "+
            FindATourDbContract.BadgeEntry.TABLE_NAME+"("+ FindATourDbContract.BadgeEntry._ID+"));";
    public FindATourDbHelper(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(SQL_CREATE_TOURIST_TABLE);
        db.execSQL(SQL_CREATE_PLACE_TABLE);
        db.execSQL(SQL_CREATE_TOUR_ADMIN_TABLE);
        db.execSQL(SQL_CREATE_TOUR_GUIDE_TABLE);
        db.execSQL(SQL_CREATE_BADGE_TABLE);
        db.execSQL(SQL_CREATE_TOUR_TABLE);
        db.execSQL(SQL_CREATE_TOUR_GUIDE_BADGE_TABLE);
        db.execSQL(SQL_CREATE_TOURIST_TOUR_TABLE);
        db.execSQL(SQL_CREATE_TOUR_PLACE_TABLE);


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXITS "+ FindATourDbContract.TourGuideBadgeEntry.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXITS "+ FindATourDbContract.TouristTourEntry.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXITS "+ FindATourDbContract.TourPlaceEntry.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXITS "+ FindATourDbContract.TourEntry.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXITS "+ FindATourDbContract.BadgeEntry.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXITS "+ FindATourDbContract.TourAdminEntry.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXITS "+ FindATourDbContract.TourGuideEntry.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXITS "+ FindATourDbContract.TouristEntry.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXITS "+ FindATourDbContract.PlaceEntry.TABLE_NAME);
        onCreate(db);




    }
    public void addTourGuide(String name, String surname, String email){
        SQLiteDatabase tourDb = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(FindATourDbContract.TourGuideEntry.COLUMN_TOUR_GUIDE_NAME, name);
        values.put(FindATourDbContract.TourGuideEntry.COLUMN_TOUR_GUIDE_SURNAME, surname);
        values.put(FindATourDbContract.TourGuideEntry.COLUMN_TOUR_GUIDE_EMAIL, email);
        values.put(FindATourDbContract.TourGuideEntry.COLUMN_TOUR_GUIDE_RATING, 0);
        long id = tourDb.insert(FindATourDbContract.TourGuideEntry.TABLE_NAME, null, values);
        Log.d(TAG," TourGuide inserted with id : "+id);
        tourDb.close();

    }
    public void deleteUser(String email)
    {

        SQLiteDatabase tourDb = this.getWritableDatabase();
        String deleteFromTouristTable = "DELETE  FROM " + FindATourDbContract.TouristEntry.TABLE_NAME + " WHERE " +
                FindATourDbContract.TouristEntry.COLUMN_TOURIST_EMAIL + " = '" + email + "' ;";
        tourDb.rawQuery(deleteFromTouristTable,null);
        String deleteFromTourGuideTable = "DELETE  FROM " + FindATourDbContract.TourGuideEntry.TABLE_NAME + " WHERE " +
                FindATourDbContract.TourGuideEntry.COLUMN_TOUR_GUIDE_EMAIL + " = '" + email + "' ;";
        tourDb.rawQuery(deleteFromTourGuideTable,null);



        //İçini doldur
    }
    public void addTourist(String name, String surname, String email)
    {
        SQLiteDatabase tourDb = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(FindATourDbContract.TouristEntry.COLUMN_TOURIST_NAME, name);
        values.put(FindATourDbContract.TouristEntry.COLUMN_TOURIST_SURNAME, surname);
        values.put(FindATourDbContract.TouristEntry.COLUMN_TOURIST_EMAIL, email);

        long id = tourDb.insert(FindATourDbContract.TouristEntry.TABLE_NAME, null ,values);
        tourDb.close();

        Log.d(TAG, " A new user insert into SQLite Database! with id: "+id);
     }
    public HashMap<String, String> getTouristDetails() {

        HashMap<String, String> user = new HashMap<String, String>();
        String selectQuery = " SELECT * FROM " + FindATourDbContract.TouristEntry.TABLE_NAME;
        SQLiteDatabase tourDb = this.getReadableDatabase();
        Cursor cursor = tourDb.rawQuery(selectQuery, null);
        cursor.moveToFirst();
        if(cursor.getCount() > 0)
        {
            user.put("name",cursor.getString(1));
            user.put("surname",cursor.getString(2));
            user.put("email",cursor.getString(3));

        }
        cursor.close();
        tourDb.close();
        Log.d(TAG," User Details from SQLite Db : "+user.toString());
        return user;
    }
    public int getRowCount() {
        String countQuery = " SELECT * FROM " + FindATourDbContract.TouristEntry.TABLE_NAME;
        SQLiteDatabase tourDb = this.getReadableDatabase();
        Cursor cursor  = tourDb.rawQuery(countQuery, null);
        int rowCount = cursor.getCount();
        tourDb.close();
        cursor.close();

        return rowCount;


    }
    public void deleteUsers() {
        SQLiteDatabase tourDb = this.getWritableDatabase();
        String deleteTouristsQuery = " DELETE FROM "+ FindATourDbContract.TouristEntry.TABLE_NAME +
                ";";
        String deleteGuideQuery = " DELETE FROM " + FindATourDbContract.TourGuideEntry.TABLE_NAME +
                ";";
        String deleteAdminQuery = " DELETE FROM " + FindATourDbContract.TourAdminEntry.TABLE_NAME +
                ";";

        tourDb.rawQuery(deleteTouristsQuery,null);
        tourDb.rawQuery(deleteGuideQuery,null);
        tourDb.rawQuery(deleteAdminQuery,null);
        Log.d(TAG," Cache Cleared!");
        tourDb.close();


    }


}






