package com.example.ozanalpay.draft3.data.Views;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TimePicker;

import com.example.ozanalpay.draft3.R;
import com.example.ozanalpay.draft3.data.data.FindATourDbHelper;
import com.example.ozanalpay.draft3.data.helper.SessionManager;

import java.util.Calendar;

public class TouristHomeActivity extends Activity {
    private final String TAG ="TouristHomeActivity";

    private EditText inputCityName;
    private EditText inputLanguage;
    private Button inputStartDate;
    private Button inputStartHour;
    private Button inputEndHour;
    private Button ListTours;
    private Button logoutButton;
    private ScrollView tourList;
    private int inputYear,inputMonth,inputDay;
    private int startHour,startMinute;
    private int endHour,endMinute;
    private ProgressDialog pDialog;
    private SessionManager sessionManager;
    private FindATourDbHelper tourDbHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tourist_home);
        inputCityName = (EditText)findViewById(R.id.tourist_home_input_city);
        inputLanguage = (EditText)findViewById(R.id.tourist_home_input_language);
        inputStartDate = (Button) findViewById(R.id.tourist_home_pick_start_date);
        inputStartHour = (Button)findViewById(R.id.tourist_home_pick_start_hour);
        inputEndHour = (Button) findViewById(R.id.tourist_home_pick_end_hour);
        ListTours = (Button) findViewById(R.id.tourist_home_list_tours_button);
        logoutButton = (Button) findViewById(R.id.tourist_home_logout_button);
        tourList = (ScrollView) findViewById(R.id.tourist_home_scroolview);
        tourDbHelper = new FindATourDbHelper(getApplicationContext());
        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);
        sessionManager = new SessionManager(getApplicationContext());


        inputStartHour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Calendar currentTime = Calendar.getInstance();
                int hour = currentTime.get(Calendar.HOUR_OF_DAY);
                int minute = currentTime.get(Calendar.MINUTE);
                TimePickerDialog timePicker;

                timePicker = new TimePickerDialog(TouristHomeActivity.this, new TimePickerDialog.OnTimeSetListener(){

                    @Override
                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute)
                    {
                        Log.d(TAG,"User selected the start time as Hour="+selectedHour+" Minute="+selectedMinute);
                        startHour = selectedHour;
                        startMinute = selectedMinute;

                    }

                },hour,minute,true);

                timePicker.setTitle("Pick Start Hour");
                timePicker.setButton(DatePickerDialog.BUTTON_POSITIVE, "Set", timePicker);
                timePicker.setButton(DatePickerDialog.BUTTON_NEGATIVE, "Cancel", timePicker);
                timePicker.show();



            }
        });
        inputEndHour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Calendar currentTime = Calendar.getInstance();
                int hour = currentTime.get(Calendar.HOUR_OF_DAY);
                int minute = currentTime.get(Calendar.MINUTE);
                TimePickerDialog timePicker;

                timePicker = new TimePickerDialog(TouristHomeActivity.this, new TimePickerDialog.OnTimeSetListener(){

                    @Override
                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute)
                    {
                        Log.d(TAG,"User selected the end time as Hour="+selectedHour+" Minute="+selectedMinute);
                        endHour = selectedHour;
                        endMinute = selectedMinute;

                    }

                },hour,minute,true);

                timePicker.setTitle("Pick A End Hour");
                timePicker.setButton(DatePickerDialog.BUTTON_POSITIVE, "Set", timePicker);
                timePicker.setButton(DatePickerDialog.BUTTON_NEGATIVE, "Cancel", timePicker);
                timePicker.show();



            }
        });
        inputStartDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Calendar CurrentDay = Calendar.getInstance();
                int day = CurrentDay.get(Calendar.DAY_OF_MONTH);
                int month = CurrentDay.get(Calendar.MONTH);
                int year = CurrentDay.get(Calendar.YEAR);

                DatePickerDialog  datePicker;

                datePicker =  new DatePickerDialog(TouristHomeActivity.this, new DatePickerDialog.OnDateSetListener(){
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int day)
                    {
                        Log.d(TAG,"User selected Date as Day = "+day+" Month = "+month+" Year = "+year);
                        inputYear = year;
                        inputMonth = month;
                        inputDay = day;
                    }
                },year, month, day);
                datePicker.setTitle("Pick Tour Date");
                datePicker.setButton(DatePickerDialog.BUTTON_POSITIVE, "Set", datePicker);
                datePicker.setButton(DatePickerDialog.BUTTON_NEGATIVE, "Cancel", datePicker);
                datePicker.show();                        }
        });
        ListTours.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Servera burda request atıcaz elimizdeki parametreler ile
                //Elimizdeki paramtereler @Language,@City,@StartDate,@StartTime,@EndTime


            }
        });
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logoutUser();
            }
        });




















    }
    private void logoutUser(){
        sessionManager.setLogin(false);
        tourDbHelper.deleteUsers();
        Intent intent = new Intent(TouristHomeActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }





    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_tourist_home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
