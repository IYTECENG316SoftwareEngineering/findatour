package com.example.ozanalpay.draft3.data.models;

/**
 * Created by OzanAlpay on 22.5.2015.
 */
public abstract class User {

    private int userId;
    private String name;
    private String emailAdress;
    private Usertype userType;

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
    public Usertype getUserType() {
        return userType;
    }

    public void setUserType(Usertype userType) {
        this.userType = userType;
    }

    public String getEmailAdress() {
        return emailAdress;
    }

    public void setEmailAdress(String emailAdress) {
        this.emailAdress = emailAdress;
    }

    public String getName() {
        return name;
    }

    protected User(int userId, String name, String emailAdress) {
        this.userId = userId;
        this.name = name;
        this.emailAdress = emailAdress;
    }

    @Override
    public String toString() {
        return "User{" +
                "emailAdress='" + emailAdress + '\'' +
                ", name='" + name + '\'' +
                ", userId=" + userId +
                '}';
    }
}
