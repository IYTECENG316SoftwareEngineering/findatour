package com.example.ozanalpay.draft3.data.Views;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.ozanalpay.draft3.R;
import com.example.ozanalpay.draft3.data.data.FindATourDbHelper;
import com.example.ozanalpay.draft3.data.helper.SessionManager;

import java.util.HashMap;

public class MainActivity extends Activity {

    private TextView nameView;
    private TextView surnameView;
    private Button logoutButton;
    private FindATourDbHelper tourDb;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameView = (TextView) findViewById(R.id.main_name_text);
        surnameView = (TextView) findViewById(R.id.main_surname_text);
        logoutButton = (Button) findViewById(R.id.logout_button);

        tourDb = new FindATourDbHelper(getApplicationContext());
        sessionManager = new SessionManager(getApplicationContext());

        if (!sessionManager.isLoggedIn()) {
            logoutUser();
        }

        HashMap<String, String> tourist = tourDb.getTouristDetails();
        String name = tourist.get("name");
        String surname = tourist.get("surname");
        nameView.setText(name);
        surnameView.setText(surname);

        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logoutUser();
            }
        });
    }

    private void logoutUser() {

            sessionManager.setLogin(false);
            tourDb.deleteUsers();
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();


    }












    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
