package com.example.ozanalpay.draft3.data.models;

/**
 * Created by OzanAlpay on 22.5.2015.
 */
public class Tour {


}
